const chalk = require('chalk');
console.log(chalk.blue('Zak Psycho MD Bot Flash Activated!'));