module.exports = {
  botName: "Zak Psycho MD",
  owner: "Zak",
  prefix: ".",
  sessionName: "session",
  version: "1.0.0"
};