const { botName, owner } = require('./set');
console.log(`Welcome to ${botName} by ${owner}!`);