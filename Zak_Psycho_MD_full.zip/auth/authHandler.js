const fs = require('fs');
module.exports = {
  isAuthenticated: (user) => {
    let data = JSON.parse(fs.readFileSync('./bdd/database.json'));
    return data.users.includes(user);
  }
};