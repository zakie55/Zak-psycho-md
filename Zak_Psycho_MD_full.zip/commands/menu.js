const { sendMessage } = require('../framework/core');
module.exports = (sock, sender) => {
  sendMessage(sock, sender, '📜 Zak Psycho MD Bot Commands 📜\n\n.ping - Check bot response\n.sticker - Convert to sticker\n.ytmp3 [link] - Download MP3');
};