module.exports = {
  sendMessage: (sock, to, message) => {
    sock.sendMessage(to, { text: message });
  }
};